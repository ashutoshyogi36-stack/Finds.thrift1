finds.thrift1 website demo
1. Keep index.html, style.css and script.js in the same folder.
2. Double-click index.html to open the site.
3. Replace demo product images, prices, policies, Instagram/WhatsApp details with the client's real information.
4. Checkout/payment is a demo and needs a real order/payment integration before launch.
